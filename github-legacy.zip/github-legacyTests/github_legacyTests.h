//
//  github_legacyTests.h
//  github-legacyTests
//
//  Created by Нестор on 25.02.25.
//  Copyright (c) 2025 Нестор. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface github_legacyTests : SenTestCase

@end
