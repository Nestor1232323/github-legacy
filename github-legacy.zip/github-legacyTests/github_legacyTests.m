//
//  github_legacyTests.m
//  github-legacyTests
//
//  Created by Нестор on 25.02.25.
//  Copyright (c) 2025 Нестор. All rights reserved.
//

#import "github_legacyTests.h"

@implementation github_legacyTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in github-legacyTests");
}

@end
