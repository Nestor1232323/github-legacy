//
//  AppDelegate.h
//  github-legacy
//
//  Created by Нестор on 25.02.25.
//  Copyright (c) 2025 Нестор. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
