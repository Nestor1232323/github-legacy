#import "ViewController.h"

@interface ViewController () <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) NSString *username; // Свойство для хранения имени пользователя
@property (nonatomic, strong) NSArray *repoFiles;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    // Загружаем данные с использованием текущего имени пользователя
    [self fetchUserData];
    [self fetchRepositories];
    
    // Показываем всплывающее окно с текстовым полем для ввода имени пользователя
    [self showPopupWithTextField];
}
// Метод для получения данных пользователя GitHub
- (void)fetchUserData {
    NSString *usernameToFetch = self.username ? self.username : @"Nestor1232323"; // Используем введенное имя, если оно есть, иначе - дефолтное "Ntclov"
    
    NSString *urlString = [NSString stringWithFormat:@"https://api.github.com/users/%@", usernameToFetch];
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        if (error) {
            NSLog(@"Error: %@", error.localizedDescription);
        } else {
            NSError *jsonError;
            NSDictionary *jsonResponse = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
            if (jsonError) {
                NSLog(@"JSON Error: %@", jsonError.localizedDescription);
            } else {
                // Проверяем на NSNull перед использованием данных
                self.userName = jsonResponse[@"name"] != [NSNull null] ? jsonResponse[@"name"] : @"Неизвестно";
                
                // Устанавливаем имя и аватарку
                self.nameLabel.text = self.userName ?: @"Неизвестно";  // Устанавливаем имя пользователя, если оно есть, иначе "Неизвестно"
                
                [self.tableView reloadData];  // Обновляем таблицу с репозиториями
            }
        }
    }];
}

// Метод для получения репозиториев пользователя
- (void)fetchRepositories {
    NSString *usernameToFetch = self.username ? self.username : @"Nestor1232323"; // Используем введенное имя, 
    
    NSString *urlString = [NSString stringWithFormat:@"https://api.github.com/users/%@/repos", usernameToFetch];
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        if (error) {
            NSLog(@"Error: %@", error.localizedDescription);
        } else {
            NSError *jsonError;
            NSArray *jsonResponse = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
            if (jsonError) {
                NSLog(@"JSON Error: %@", jsonError.localizedDescription);
            } else {
                self.repositories = jsonResponse;  // Присваиваем данные в массив
                
                // Логируем, сколько репозиториев получено
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self.tableView reloadData];
                });
            }
        }
    }];
}

// Метод UITableViewDataSource для количества строк
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.repositories.count; // Возвращаем количество репозиториев
}

// Метод UITableViewDataSource для настройки ячеек
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"RepoCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    NSDictionary *repo = self.repositories[indexPath.row];
    cell.textLabel.text = repo[@"name"];  // Устанавливаем имя репозитория
    
    return cell;
}

// Ваш код для отображения UIAlertView с текстовым полем
- (void)showPopupWithTextField {
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Введите свой username на GitHub"
                                                        message:nil
                                                       delegate:self
                                              cancelButtonTitle:@"Отмена"
                                              otherButtonTitles:@"OK", nil];
    
    // Добавляем текстовое поле в UIAlertView
    alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
    
    // Получаем текстовое поле и настраиваем его (например, задаем placeholder)
    UITextField *textField = [alertView textFieldAtIndex:0];
    textField.placeholder = @"Например: igkuzm";
    
    // Показываем UIAlertView
    [alertView show];
}

// Делегат метода для обработки нажатия кнопок
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) { // Если нажата кнопка OK
        UITextField *textField = [alertView textFieldAtIndex:0];
        NSString *enteredText = textField.text;
        
        // Сохраняем введенное имя пользователя
        self.username = enteredText;
        
        // Логируем введенное имя
        NSLog(@"Введенный текст: %@", enteredText);
        
        // Теперь нужно заново загрузить данные с новым именем пользователя
        [self fetchUserData];
        [self fetchRepositories];
    }
}



@end
