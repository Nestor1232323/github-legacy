#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, NSURLConnectionDelegate>

// Привязка для UITableView
@property (weak, nonatomic) IBOutlet UITableView *tableView;

// Привязки для элементов, отображающих имя пользователя и аватарку
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;     // Лейбл для имени пользователя

// Данные пользователя
@property (strong, nonatomic) NSString *userName;
@property (strong, nonatomic) NSString *avatarURL;

// Данные о репозиториях
@property (nonatomic, strong) NSArray *repositories; // Массив для хранения репозиториев
@property (nonatomic, strong) NSArray *dataArray; // Данные для отображения
@property (nonatomic, assign) BOOL showingRepositories; // Флаг: показываем репозитории или релизы
@property (nonatomic, strong) NSString *selectedRepo; // Выбранный репозиторий
@property (nonatomic, strong) NSMutableData *receivedData; // Данные, полученные от запроса
@end
