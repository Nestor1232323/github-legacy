// ViewRepo.m
#import "ViewRepo.h"
#import <Foundation/Foundation.h>

@interface ViewRepo ()

// Свойство для хранения полученных данных
@property (nonatomic, strong) NSMutableData *receivedData;

@end

@implementation ViewRepo

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    // Загружаем файлы репозитория с GitHub
    [self loadRepositoryFiles];
}

- (void)loadRepositoryFiles {
    NSString *urlString = [NSString stringWithFormat:@"https://api.github.com/repos/Ntclov/%@/contents", self.repoName];
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    // Отправляем запрос
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        if (error) {
            NSLog(@"Ошибка при загрузке файлов: %@", error.localizedDescription);
            return;
        }
        
        NSError *jsonError;
        NSArray *jsonResponse = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
        
        if (jsonError) {
            NSLog(@"Ошибка при парсинге JSON: %@", jsonError.localizedDescription);
        } else {
            // Обработка полученных файлов
            NSMutableArray *fileNames = [NSMutableArray array];
            for (NSDictionary *file in jsonResponse) {
                [fileNames addObject:file[@"name"]];
            }
            
            self.files = [fileNames copy]; // Сохраняем файлы в свойство
            
            // Обновляем таблицу
            [self.tableView reloadData];
        }
    }];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.files.count;  // Количество файлов
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"FileCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Отображаем имя файла
    cell.textLabel.text = self.files[indexPath.row];
    
    return cell;
}

@end
