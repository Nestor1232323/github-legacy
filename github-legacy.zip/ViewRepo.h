//
//  ViewRepo.h
//  github-legacy
//
//  Created by Нестор on 26.02.25.
//  Copyright (c) 2025 Нестор. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewRepo : UIViewController <UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) NSString *repoName;
@property (strong, nonatomic) NSArray *repoFiles;
@property (strong, nonatomic) NSArray *repositories;
@property (nonatomic, strong) NSArray *files;

@end
